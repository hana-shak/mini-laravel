<?php $__env->startSection('content'); ?>
  <h1>Show Data Page <?php echo e($id); ?> <?php echo e($name); ?> <?php echo e($email); ?> </h1>

  <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

  <script>alert('Hello visitor')</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\blog\resources\views/showdata.blade.php ENDPATH**/ ?>