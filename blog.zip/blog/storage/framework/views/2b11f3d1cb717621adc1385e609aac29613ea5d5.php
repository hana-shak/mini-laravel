<?php $__env->startSection('content'); ?>

<form action="" method="POST" class="pb-5">
    <div class="class input-group">
        <label for="">Name:</label>
        <input type="text" name="name">
        <br><br><br>
        <label for="">Job</label>
        <input type="text" name="job">
        <br><br>
    </div>

   <button type="submit">Add</button>

   <?php echo csrf_field(); ?>
   <div> <?php echo e($errors->first('name')); ?> <?php echo e($errors->first('job')); ?></div>

</form>

<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($customer['name']); ?>-><?php echo e($customer['job']); ?></li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\blog\resources\views/Trainee/form.blade.php ENDPATH**/ ?>