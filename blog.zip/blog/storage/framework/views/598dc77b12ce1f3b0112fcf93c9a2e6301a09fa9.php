<?php $__env->startSection('content'); ?>
  <h1>Contact Page </h1>

  <?php if(count($people)): ?> 
   <ul>
     <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li><?php echo e($person); ?></li>
        
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </ul>
  <?php endif; ?>

  <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

  <script>alert('Hello visitor')</script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test\blog\resources\views/contact.blade.php ENDPATH**/ ?>