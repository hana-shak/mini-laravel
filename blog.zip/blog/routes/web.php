<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\CustomerController;

Route::get('/', function () {
    return view('home');
});

Route::get('/contact', function () {
    return view('contact_us');
});

Route::get('/about', function () {
    return view('about_us');
});

Route::get('/services', function () {
    return view('services');
});

// Route::get('/hey', function(){
//     return "Hey Hana";

// });


// Route::get('/post/{id}/{name}', function($id,$name){
//     return "This is post number".$id ."   " . $name;
// });

// Route::get('/admin/post/example', array('as'=>'admin.home', function(){

//    $url = route('admin.home');
//    return "this is". $url;

    //   <a href="route('admin.home')"> CLICK HERE </a>;  wrong

// }));

// Route::get('/cont','NewController@index');


// Route::resource('/conto', 'NewController');

// Route::get('/conto', 'NewController@contact');

// Route::get('/conto/{id}/{name}/{email}', 'NewController@show_data');


Route::get('/Trainee/', 'TraineesController@index');
// Route::get('/Trainee/trainee{id}', 'TraineesController@trainee');
Route::get('/Trainee/gallery', 'TraineesController@gallery');
Route::get('/Trainee/dashboard', 'TraineesController@dashboard');
Route::get('/Trainee/trainees', 'TraineesController@hana');
// Route::get('/Trainee/home', 'TraineesController');
Route::get('/Trainee/home/', function () {
    return view('home');
});


// DATABASE Row SQL Queries

// INSERT INTO DB
// Route::get('/insert', function(){
//      DB::insert('insert into users (name,descr,confirm) values (?,?,?)',['Lala','Hana is the BEST',1]);
//      DB::insert('insert into users (name,descr,confirm) values (?,?,?)',['lolo','lolo is the BEST',0]);
//      DB::insert('insert into users (name,descr,confirm) values (?,?,?)',['lele','lele is the BEST',0]);
//      DB::insert('insert into users (name,descr,confirm) values (?,?,?)',['Lana','lana is the BEST',1]);
//      DB::insert('insert into users (name,descr,confirm) values (?,?,?)',['Laila','laila is the BEST',1]);
// });

// READ DATA FROM DB
// Route::get('/select',function(){
    //     $results = DB::select('select * from users where id = ?',[1]);
//         var_dump($results);
//         return$results;

    // foreach($results as $key => $val){
    //     $x= $key;
    //     $y=$val;
    //     return $val->name;
    // }

    // foreach($results as $val){
    //     $y=$val;
    //     return $val->name;
        // return $val->descr;
        // return $val->confirm;
    // }
        // dd($y);

// });

// UPDATE DATA IN DB
// Route::get('/update',function(){

//    $updated = DB::update('update users set name = "hana" where id=?',[1]);
//     return $updated;
// });

// DELETE DATA IN DB
// Route::get('/delete', function(){

//     $deleted = DB::delete('delete from users where id = ?', [1]);
//     return $deleted;
// });

Route::get('customers', 'CustomerController@list');
Route::post('customers', 'CustomerController@store');
