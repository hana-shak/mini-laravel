@extends('layouts.master');

@section('title')
Home
@endsection