@extends('layouts.app')

@section('content')

<form action="" method="POST" class="pb-5">
    <div class="class input-group">
        <label for="">Name:</label>
        <input type="text" name="name">
        <br><br><br>
        <label for="">Email:</label>
        <input type="text" name="email">
        <br><br><br>
        <label for="">Job</label>
        <input type="text" name="job">
        <br><br>
    </div>

   <button type="submit">Add</button>

   @csrf
   <div> {{ $errors->first('name')}} and {{$errors->first('job')}}</div>

</form>

@foreach ($customers as $customer)
<li>{{$customer['name']}}->{{$customer['job']}}</li>
{{-- {{$customer}} --}}
@endforeach
@endsection
