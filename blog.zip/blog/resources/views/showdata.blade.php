@extends('layouts.app')

@section('content')
  <h1>Show Data Page {{$id}} {{$name}} {{$email}} </h1>

  @endsection

@section('footer')

  <script>alert('Hello visitor')</script>